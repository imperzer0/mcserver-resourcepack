The organization on these isn't the best. you can use any of these textures as long as you credit me and link my texturepack page.

Key:

I labeled the later entries in this pack with alphabetical codes.

the order I added the wings follow the alphabetical order, so wing a.png comes before wing b.png.

suffix:

i : icon
ib: icon broken (not all the way implemented
_e: emmisive
_s: specular map (Used in some shaders e.g. SEUS PTGI)
_n: normal map (Used in some shaders e.g. SEUS PTGI)